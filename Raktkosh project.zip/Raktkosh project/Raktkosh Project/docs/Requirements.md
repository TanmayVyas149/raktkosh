Requirements
-------------------------------
Users.
  - User
      - Donor.
      - Acceptor.
  - Blood banks

Attributes
  - Users
    - Name
    - Age
    - Gender
    - Weight
    - Height
    - Ailments (Any)

  - Blood Banks
    - Name.
    - Location.
    - Contacts.
    - No. of Donors.
    - Opening Hours.
