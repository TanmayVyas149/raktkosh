export const switchTheme = () => ({ type: 'SWITCH_THEME' });

export const setUserDetails = payload => ({
  type: 'SET_USER_DETAILS',
  payload
});
