# Raktkosh

>Connecting Donors and Receivers.

---
## Description

Raktkosh is an online platform that allows blood receivers to find and contact donors easily, in shortest possible time.

---
## Development Tool
  - Spring Boot
  - Hibernate
  - MySQL
  - MongoDB
  - React
  - Redux
  - Sass

---
Developed with ❤️️ by
  - Charu Tayal
  - Rutuja Dighe
  - Upender Yadav
  - Dhananjay Andhale
  - Anshuman Gupta