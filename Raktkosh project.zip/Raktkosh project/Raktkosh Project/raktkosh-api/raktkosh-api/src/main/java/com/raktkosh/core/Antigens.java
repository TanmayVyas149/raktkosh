package com.raktkosh.core;

public enum Antigens {
  POSITIVE, NEGATIVE
}
