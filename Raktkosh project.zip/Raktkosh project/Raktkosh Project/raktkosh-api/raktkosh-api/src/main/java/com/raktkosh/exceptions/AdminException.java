package com.raktkosh.exceptions;

public class AdminException extends RuntimeException {
	  private static final long serialVersionUID = 17L;
	  
	  public AdminException(String message) {
	    super(message);
	  }
	}

