package com.raktkosh.core;

public enum Role {
  USER,
  ADMIN,
  BLOOD_BANK
}
