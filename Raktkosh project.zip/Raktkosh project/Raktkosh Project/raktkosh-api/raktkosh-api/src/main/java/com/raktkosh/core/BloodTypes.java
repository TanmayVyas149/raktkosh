package com.raktkosh.core;

public enum BloodTypes {
  O, A, B, AB
}
