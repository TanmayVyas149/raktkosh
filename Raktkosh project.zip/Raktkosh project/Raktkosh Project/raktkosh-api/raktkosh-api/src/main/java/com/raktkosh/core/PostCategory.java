package com.raktkosh.core;

public enum PostCategory {
	DONOR, RECEIVER

}
